// src/context/authcontext.jsx
import React, { createContext, useContext, useState, useEffect } from "react";
import { Navigate } from "react-router-dom";
import api from "../api/login_api.js";

const AuthContext = createContext(null);

const SUPERADMIN_EMAILS = [
  'superadmin@company.com',
  'superadmin@teamcomputers.com',
];

// ─── Provider ────────────────────────────────────────────────────────────────

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // true while checking session

  // On app load, restore session via /auth/me (cookie-based)
  useEffect(() => {
    api.get("/auth/me", { params: { _ts: Date.now() } })
      .then((res) => {
        const u = res.data.data;
        setUser({
          id:      u.id,
          name:    u.name,
          email:   u.email,
          role_id: u.role_id,
          role:    u.role_name || u.role || "User",
        });
      })
      .catch(() => {
        setUser(null); // Not logged in — cookie missing or expired
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  // Accepts both raw API shape (role_name) and pre-processed shape (role)
  const login = (apiUser) => {
    setUser({
      id:      apiUser.id,
      name:    apiUser.name,
      email:   apiUser.email,
      role_id: apiUser.role_id,
      role:    apiUser.role || apiUser.role_name || "User",
    });
  };

  const logout = async () => {
    try {
      await api.post("/auth/logout");
    } catch {
      // Clear local state even if API call fails
    }
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useAuth() {
  return useContext(AuthContext);
}

// ─── Role helpers (shared by route guards) ───────────────────────────────────

const isSuperAdminUser = (user) => {
  if (!user) return false;
  const roleId = Number(user.role_id);
  const role   = (user.role  || '').toLowerCase().replace(/\s/g, '');
  const email  = (user.email || '').toLowerCase();
  return (
    roleId === 0 || roleId === 5 || roleId === 6 || roleId === 7 ||
    role === 'superadmin' || role === 'super_admin' ||
    SUPERADMIN_EMAILS.includes(email)
  );
};

const isAdminUser = (user) => {
  if (!user) return false;
  const roleId = Number(user.role_id);
  const role   = (user.role || '').toLowerCase().replace(/\s/g, '');
  return (roleId === 1 || role === 'admin') && !isSuperAdminUser(user);
};

// ─── Route Guards ─────────────────────────────────────────────────────────────

export const SuperAdminRoute = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) return <div className="loading-screen">Loading…</div>;
  if (!user)   return <Navigate to="/login" replace />;

  if (!isSuperAdminUser(user)) return <Navigate to="/" replace />;
  return children;
};

export const AdminRoute = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) return <div className="loading-screen">Loading…</div>;
  if (!user)   return <Navigate to="/login" replace />;

  if (!isAdminUser(user)) return <Navigate to="/" replace />;
  return children;
};
