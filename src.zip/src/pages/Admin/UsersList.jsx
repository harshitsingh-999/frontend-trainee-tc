import { useEffect, useState } from 'react';
import { useUser } from '../../Contexts/UserContext';

const UsersList = () => {
  const { users, loading, error, fetchUsers, toggleUserStatus } = useUser();
  const [actionError, setActionError] = useState('');
  const [actionSuccess, setActionSuccess] = useState('');
  const [togglingUserId, setTogglingUserId] = useState(null);
  const [search, setSearch] = useState('');
  const [filterRole, setFilterRole] = useState('all');

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  const handleToggleStatus = async (user) => {
    setTogglingUserId(user.id);
    setActionError('');
    setActionSuccess('');
    try {
      const newStatus = user.is_active ? 0 : 1;
      await toggleUserStatus(user.id, newStatus === 1);
      setActionSuccess(`User ${newStatus === 1 ? 'activated' : 'deactivated'} successfully`);
      setTimeout(() => setActionSuccess(''), 3000);
    } catch (err) {
      setActionError(err.message || 'Error updating user status');
    } finally {
      setTogglingUserId(null);
    }
  };

  const getRoleName = (roleId) => {
    const roles = { 1: 'Admin', 2: 'Manager', 3: 'Trainee', 4: 'Intern' };
    return roles[roleId] || 'Unknown';
  };

  const getRoleColor = (roleId) => {
    const colors = { 1: '#6366f1', 2: '#0ea5e9', 3: '#10b981', 4: '#f59e0b' };
    return colors[roleId] || '#94a3b8';
  };

  const filteredUsers = users.filter(u => {
    const matchSearch = u.name?.toLowerCase().includes(search.toLowerCase()) ||
                        u.email?.toLowerCase().includes(search.toLowerCase());
    const matchRole = filterRole === 'all' || u.role_id === parseInt(filterRole);
    return matchSearch && matchRole;
  });

  if (loading) return (
    <div className="dash-loading">
      <div className="loading-spinner"></div>
      <span>Loading users...</span>
    </div>
  );

  return (
    <div className="users-page">
      <div className="page-header">
        <div>
          <h2>Manage Users</h2>
          <p className="page-desc">View, activate and manage all system users</p>
        </div>
        <a href="/admin/create-user" className="btn-create">
          <span>⊕</span> Create User
        </a>
      </div>

      {error && <div className="dash-error">{error}</div>}
      {actionError && <div className="dash-error">{actionError}</div>}
      {actionSuccess && <div className="dash-success">{actionSuccess}</div>}

      {/* Filters */}
      <div className="table-toolbar">
        <div className="search-box">
          <span className="search-icon">⊙</span>
          <input
            type="text"
            placeholder="Search by name or email..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="search-input"
          />
        </div>
        <div className="filter-group">
          <select value={filterRole} onChange={e => setFilterRole(e.target.value)} className="role-filter">
            <option value="all">All Roles</option>
            <option value="1">Admin</option>
            <option value="2">Manager</option>
            <option value="3">Trainee</option>
            <option value="4">Intern</option>
          </select>
          <button onClick={() => { setSearch(''); setFilterRole('all'); fetchUsers(); }} className="refresh-btn">
            Refresh
          </button>
        </div>
      </div>

      <div className="table-meta">
        Showing {filteredUsers.length} of {users.length} users
      </div>

      {filteredUsers.length === 0 ? (
        <div className="empty-state">
          <span>◈</span>
          <p>No users found matching your filters.</p>
        </div>
      ) : (
        <div className="table-wrap">
          <table className="users-table">
            <thead>
              <tr>
                <th>#</th>
                <th>User</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user, i) => (
                <tr key={user.id}>
                  <td className="td-id">{i + 1}</td>
                  <td>
                    <div className="user-cell">
                      <div className="user-avatar-sm" style={{background: getRoleColor(user.role_id)}}>
                        {user.name?.charAt(0)?.toUpperCase() || '?'}
                      </div>
                      <span className="user-name-cell">{user.name}</span>
                    </div>
                  </td>
                  <td className="td-email">{user.email}</td>
                  <td>
                    <span className="role-badge" style={{background: getRoleColor(user.role_id) + '18', color: getRoleColor(user.role_id)}}>
                      {getRoleName(user.role_id)}
                    </span>
                  </td>
                  <td>
                    <span className={`status-badge ${user.is_active ? 'status-active' : 'status-inactive'}`}>
                      <span className="status-dot"></span>
                      {user.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td>
                    <button
                      onClick={() => handleToggleStatus(user)}
                      disabled={togglingUserId === user.id}
                      className={`toggle-btn ${user.is_active ? 'toggle-deactivate' : 'toggle-activate'}`}
                    >
                      {togglingUserId === user.id ? '...' : user.is_active ? 'Deactivate' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default UsersList;