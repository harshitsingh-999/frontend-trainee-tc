import { useState, useEffect } from 'react';
import axiosClient from '../../api/axiosClient';

const StatCard = ({ label, value, icon, color, trend }) => (
  <div className="stat-card" style={{'--card-color': color}}>
    <div className="stat-icon">{icon}</div>
    <div className="stat-body">
      <span className="stat-label">{label}</span>
      <span className="stat-value">{value}</span>
      {trend && <span className="stat-trend">{trend}</span>}
    </div>
    <div className="stat-bg-icon">{icon}</div>
  </div>
);

const Dashboard = () => {
  const [metrics, setMetrics] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  useEffect(() => { fetchMetrics(); }, []);

  const fetchMetrics = async () => {
    try {
      const response = await axiosClient.get('/api/v1/admin/dashboard');
      if (response.data.success) setMetrics(response.data.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch dashboard metrics');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return (
    <div className="dash-loading">
      <div className="loading-spinner"></div>
      <span>Loading dashboard...</span>
    </div>
  );

  return (
    <div className="admin-dashboard">

      {/* Welcome Banner */}
      <div className="welcome-banner">
        <div className="welcome-text">
          <h1>{greeting}, {user.name || 'Admin'}</h1>
          <p>Here is what is happening in your system today.</p>
        </div>
        <div className="welcome-date">
          {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </div>
      </div>

      {error && <div className="dash-error">{error}</div>}

      {/* Stat Cards */}
      <div className="stats-row">
        <StatCard label="Total Users" value={metrics.totalUsers ?? 0} icon="◈" color="#6366f1" trend="+2 this week" />
        <StatCard label="Total Trainees" value={metrics.totalTrainees ?? 0} icon="◉" color="#0ea5e9" trend="Active" />
        <StatCard label="Departments" value={metrics.totalDepartments ?? 0} icon="▣" color="#10b981" trend="Across org" />
        <StatCard label="Pending Tasks" value={metrics.pendingTasks ?? 0} icon="⊡" color="#f59e0b" trend="Need review" />
      </div>

      {/* Two column section */}
      <div className="dash-grid">

        {/* Quick Actions */}
        <div className="dash-card">
          <div className="card-header">
            <h3>Quick Actions</h3>
            <span className="card-tag">Shortcuts</span>
          </div>
          <div className="quick-actions">
            <a href="/admin/create-user" className="quick-action-btn qa-primary">
              <span>⊕</span>
              <div>
                <strong>Create User</strong>
                <small>Add manager, intern or trainee</small>
              </div>
            </a>
            <a href="/admin/users" className="quick-action-btn qa-secondary">
              <span>◈</span>
              <div>
                <strong>Manage Users</strong>
                <small>View and edit all users</small>
              </div>
            </a>
            <a href="/admin/trainees" className="quick-action-btn qa-tertiary">
              <span>◉</span>
              <div>
                <strong>View Trainees</strong>
                <small>Track trainee progress</small>
              </div>
            </a>
          </div>
        </div>

        {/* System Status */}
        <div className="dash-card">
          <div class="card-header">
            <h3>System Status</h3>
            <span className="card-tag online">All Systems OK</span>
          </div>
          <div className="status-list">
            <div className="status-row">
              <span className="status-name">API Server</span>
              <div className="status-bar"><div className="status-fill" style={{width:'98%', background:'#10b981'}}></div></div>
              <span className="status-pct">98%</span>
            </div>
            <div className="status-row">
              <span className="status-name">Database</span>
              <div className="status-bar"><div className="status-fill" style={{width:'95%', background:'#6366f1'}}></div></div>
              <span className="status-pct">95%</span>
            </div>
            <div className="status-row">
              <span className="status-name">Auth Service</span>
              <div className="status-bar"><div className="status-fill" style={{width:'100%', background:'#0ea5e9'}}></div></div>
              <span className="status-pct">100%</span>
            </div>
            <div className="status-row">
              <span className="status-name">Storage</span>
              <div className="status-bar"><div className="status-fill" style={{width:'72%', background:'#f59e0b'}}></div></div>
              <span className="status-pct">72%</span>
            </div>
          </div>
        </div>

      </div>

      {/* Recent Activity */}
      <div className="dash-card activity-card">
        <div className="card-header">
          <h3>Recent Activity</h3>
          <button className="card-refresh-btn" onClick={fetchMetrics}>Refresh</button>
        </div>
        <div className="activity-list">
          <div className="activity-item">
            <div className="activity-dot" style={{background:'#10b981'}}></div>
            <div className="activity-info">
              <span className="activity-title">System metrics updated</span>
              <span className="activity-time">Just now</span>
            </div>
          </div>
          <div className="activity-item">
            <div className="activity-dot" style={{background:'#6366f1'}}></div>
            <div className="activity-info">
              <span className="activity-title">Admin logged in</span>
              <span className="activity-time">Today</span>
            </div>
          </div>
          <div className="activity-item">
            <div className="activity-dot" style={{background:'#0ea5e9'}}></div>
            <div className="activity-info">
              <span className="activity-title">{metrics.totalUsers ?? 0} users in system</span>
              <span className="activity-time">Current</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};

export default Dashboard;