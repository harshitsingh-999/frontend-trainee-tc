import { useState } from 'react';
import { useUser } from '../../Contexts/UserContext';

const CreateUser = () => {
  const { createUserData } = useUser();
  const [formData, setFormData] = useState({ name: '', email: '', password: '', role_id: 4 });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [showPass, setShowPass] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: name === 'role_id' ? parseInt(value) : value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setMessage('');
    try {
      await createUserData(formData);
      setMessage('User created successfully!');
      setFormData({ name: '', email: '', password: '', role_id: 4 });
      setTimeout(() => setMessage(''), 4000);
    } catch (err) {
      setError(err.message || 'Error creating user');
    } finally {
      setLoading(false);
    }
  };

  const roleInfo = {
    1: { label: 'Admin', desc: 'Full system access', color: '#6366f1' },
    2: { label: 'Manager', desc: 'Manage teams and trainees', color: '#0ea5e9' },
    3: { label: 'Trainee', desc: 'Trainee level access', color: '#10b981' },
    4: { label: 'Intern', desc: 'Basic intern access', color: '#f59e0b' },
  };

  const selected = roleInfo[formData.role_id];

  return (
    <div className="create-user-page">
      <div className="page-header">
        <div>
          <h2>Create New User</h2>
          <p className="page-desc">Add a new user to the system with a specific role</p>
        </div>
        <a href="/admin/users" className="btn-secondary-link">View All Users</a>
      </div>

      <div className="create-user-grid">

        {/* Form */}
        <div className="create-form-card">
          {message && (
            <div className="dash-success">
              <span>✓</span> {message}
            </div>
          )}
          {error && (
            <div className="dash-error">
              <span>!</span> {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="create-form">
            <div className="form-group">
              <label>Full Name</label>
              <input
                type="text"
                name="name"
                placeholder="e.g. John Smith"
                value={formData.name}
                onChange={handleChange}
                required
                disabled={loading}
              />
            </div>

            <div className="form-group">
              <label>Email Address</label>
              <input
                type="email"
                name="email"
                placeholder="e.g. john@teamcomputers.com"
                value={formData.email}
                onChange={handleChange}
                required
                disabled={loading}
              />
            </div>

            <div className="form-group">
              <label>Password</label>
              <div className="pass-wrap">
                <input
                  type={showPass ? 'text' : 'password'}
                  name="password"
                  placeholder="Minimum 8 characters"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  disabled={loading}
                />
                <button type="button" className="pass-toggle" onClick={() => setShowPass(!showPass)}>
                  {showPass ? 'Hide' : 'Show'}
                </button>
              </div>
            </div>

            <div className="form-group">
              <label>Assign Role</label>
              <div className="role-cards">
                {Object.entries(roleInfo).map(([id, info]) => (
                  <label key={id} className={`role-card ${formData.role_id === parseInt(id) ? 'role-selected' : ''}`} style={{'--role-color': info.color}}>
                    <input type="radio" name="role_id" value={id} checked={formData.role_id === parseInt(id)} onChange={handleChange} />
                    <span className="role-card-label">{info.label}</span>
                    <span className="role-card-desc">{info.desc}</span>
                  </label>
                ))}
              </div>
            </div>

            <button type="submit" disabled={loading} className="submit-btn">
              {loading ? (
                <><span className="btn-spinner"></span> Creating...</>
              ) : (
                <><span>⊕</span> Create User</>
              )}
            </button>
          </form>
        </div>

        {/* Preview Card */}
        <div className="user-preview-card">
          <h4>Preview</h4>
          <div className="preview-avatar" style={{background: selected.color}}>
            {formData.name ? formData.name.charAt(0).toUpperCase() : '?'}
          </div>
          <div className="preview-name">{formData.name || 'Full Name'}</div>
          <div className="preview-email">{formData.email || 'email@example.com'}</div>
          <div className="preview-role-badge" style={{background: selected.color + '18', color: selected.color}}>
            {selected.label}
          </div>
          <p className="preview-desc">{selected.desc}</p>

          <div className="preview-checklist">
            <div className={`check-item ${formData.name ? 'check-done' : ''}`}>
              <span>{formData.name ? '✓' : '○'}</span> Name entered
            </div>
            <div className={`check-item ${formData.email ? 'check-done' : ''}`}>
              <span>{formData.email ? '✓' : '○'}</span> Email entered
            </div>
            <div className={`check-item ${formData.password ? 'check-done' : ''}`}>
              <span>{formData.password ? '✓' : '○'}</span> Password set
            </div>
            <div className="check-item check-done">
              <span>✓</span> Role assigned
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default CreateUser;