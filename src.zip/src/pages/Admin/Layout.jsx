import { Outlet, Link, useLocation } from 'react-router-dom';
import { useState } from 'react';
import './admin.css';

const AdminLayout = () => {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
    window.location.href = '/login';
  };

  const user = JSON.parse(localStorage.getItem('user') || '{}');

  const navItems = [
    { to: '/admin/dashboard', icon: '▣', label: 'Dashboard' },
    { to: '/admin/users', icon: '◈', label: 'Manage Users' },
    { to: '/admin/create-user', icon: '⊕', label: 'Create User' },
    { to: '/admin/trainees', icon: '◉', label: 'Trainees' },
  ];

  return (
    <div className={`admin-layout ${collapsed ? 'layout-collapsed' : ''}`}>
      <aside className={`admin-sidebar ${collapsed ? 'collapsed' : ''}`}>

        <div className="sidebar-brand">
          <button className="hamburger-btn" onClick={() => setCollapsed(!collapsed)}>
            <span></span><span></span><span></span>
          </button>
          {!collapsed && (
            <div className="brand-info">
              <span className="brand-title">AdminPanel</span>
              <span className="brand-sub">TeamComputers</span>
            </div>
          )}
        </div>

        {!collapsed && (
          <div className="sidebar-profile">
            <div className="profile-avatar">
              {user.name ? user.name.charAt(0).toUpperCase() : 'A'}
            </div>
            <div className="profile-info">
              <span className="profile-name">{user.name || 'Admin'}</span>
              <span className="profile-role">Administrator</span>
            </div>
          </div>
        )}

        <nav className="admin-nav">
          {!collapsed && <span className="nav-section-label">MAIN MENU</span>}
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={`admin-nav-link ${location.pathname === item.to ? 'active' : ''}`}
              title={collapsed ? item.label : ''}
            >
              <span className="nav-icon">{item.icon}</span>
              {!collapsed && <span className="nav-label">{item.label}</span>}
              {!collapsed && location.pathname === item.to && <span className="nav-dot"></span>}
            </Link>
          ))}

          {!collapsed && <span className="nav-section-label" style={{marginTop: '16px'}}>ACCOUNT</span>}
          <button onClick={handleLogout} className="admin-logout-btn" title={collapsed ? 'Logout' : ''}>
            <span className="nav-icon">⏻</span>
            {!collapsed && <span>Logout</span>}
          </button>
        </nav>

        {!collapsed && (
          <div className="sidebar-footer">
            v1.0.0 &nbsp;·&nbsp; Admin
          </div>
        )}
      </aside>

      <div className="admin-body">
        <header className="admin-topbar">
          <div className="topbar-left">
            <h2 className="page-heading">
              {navItems.find(n => location.pathname.startsWith(n.to))?.label || 'Dashboard'}
            </h2>
            <span className="breadcrumb">Admin / {navItems.find(n => location.pathname.startsWith(n.to))?.label || 'Dashboard'}</span>
          </div>
          <div className="topbar-right">
            <div className="topbar-badge">
              <span className="badge-dot"></span>
              System Online
            </div>
            <div className="topbar-user">
              <div className="topbar-avatar">{user.name ? user.name.charAt(0).toUpperCase() : 'A'}</div>
              <span className="topbar-name">{user.name || 'Admin'}</span>
            </div>
          </div>
        </header>

        <main className="admin-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;